<?php
$connection =mysqli_connect('localhost', 'root', '',  'jahir');
if($connection){

}else{
die("wrong");
}

/*
$connection = mysqli_connect('box5934', 'xorlpgmy_jahid', 'K,r%cY;Y(+ha', 'xorlpgmy_jahid');
if ($connection) {

} else {
    die("wrong");
}*/



